// module.exports = {
//     host: '', // SMTP server host
//     port: 587, // Port for SMTP server (587 for TLS, 465 for SSL)
//     secure: false, // Set to true if you're using SSL/TLS
//     auth: {
//         user: '', // Your email address
//         pass: '' // Your email password or application-specific password
//     }
// };